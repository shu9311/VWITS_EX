package account;
import java.sql.*;

public class JDBClayer {
	
	
	public void createrecord(String name,String accno,int bal) {
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useSSL=false","root","root");){
		PreparedStatement st2 = con.prepareStatement("INSERT INTO account(name, accno, balance) VALUES(?,?,?)" );
		st2.setString(1, name);
		st2.setString(2, accno);
		st2.setInt(3,bal);
		int rowsinserted =st2.executeUpdate();
		if(rowsinserted>0) {
			System.out.println("inserted");
		}
	}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleterecord (String accno) {
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useSSL=false","root","root");){
		PreparedStatement st2 = con.prepareStatement("DELETE from account where accno=?" );
		st2.setString(1, accno);
		int rowsinserted =st2.executeUpdate();
		if(rowsinserted>0) {
			System.out.println("deleted acoount");
		}
	}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void updaterecord (String accno,int bala) {
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useSSL=false","root","root");){
		PreparedStatement st2 = con.prepareStatement("UPDATE account SET balance=? where accno=?" );
		st2.setInt(1, bala);
		st2.setString(2, accno);
		int rowsinserted =st2.executeUpdate();
		if(rowsinserted>0) {
			System.out.println("updated");
		}
	}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void retrive (String accno) {
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useSSL=false","root","root");){
		PreparedStatement st2 = con.prepareStatement("Select * from account where accno=?" );
		st2.setString(1, accno);
		ResultSet r = st2.executeQuery();
		while(r.next()) {
			System.out.println("holder name "+r.getString(1)+" with accouint no"+r.getString(2)+"with account balance"+r.getInt(3));
		}
	}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test?useSSL=false","root","root");) {
			
			PreparedStatement st = con.prepareStatement("Select * from account");
			PreparedStatement st1 = con.prepareStatement("Select name,balance from account");
			
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	}

}
