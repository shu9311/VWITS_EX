package account;

import java.util.ArrayList;

public class Acc {
	
	private String Aname;
	private String Ano;
	private int Abal;
	ArrayList<Acc> t = new ArrayList<>();
	public Acc() {
		
	}
	
	public Acc(String aname, String ano, int abal) {
		super();
		Aname = aname;
		Ano = ano;
		Abal = abal;
	}
	
	
	public String getAname() {
		return Aname;
	}
	public void setAname(String aname) {
		Aname = aname;
	}
	public String getAno() {
		return Ano;
	}
	public void setAno(String ano) {
		Ano = ano;
	}
	public int getAbal() {
		return Abal;
	}
	public void setAbal(int abal) {
		Abal = abal;
	}
    
	public void deposit(int amount) {
		this.Abal=this.Abal+amount;
	}
	
	
	public void createacc(Acc y) {
		t.add(y);
	}
	public int withdraw(int amount) throws Zerobalance{
		
		if(this.Abal==0) {
			throw new Zerobalance(this.Abal,amount,this.Ano);
		}
		else {
			this.Abal=this.Abal-amount;
			System.out.println("After withdrawing the current status of account balance is "+this.Abal);
			
		}
		return Abal;
		
	}


	@Override
	public String toString() {
		return "Acc [Aname=" + Aname + ", Ano=" + Ano + ", Abal=" + Abal + "]";
	}

	
	
	
	
	

}
