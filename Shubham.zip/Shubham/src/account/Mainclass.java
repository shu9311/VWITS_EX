package account;

import java.util.HashMap;
import java.util.Scanner;

public class Mainclass {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		HashMap<String,Acc> v = new HashMap<String,Acc>();
		String name = sc.next();
		String accountNo=sc.next();
		int balance = sc.nextInt();
		
		Acc a = new Acc(name,accountNo,balance);
		v.put(accountNo, a);
		
		JDBClayer h = new JDBClayer();
		h.createrecord(a.getAname(), a.getAno(), a.getAbal());
		h.retrive(accountNo);
		System.out.println(v);
		try {
			int tab = a.withdraw(1000);
		h.updaterecord(accountNo, tab);
		}
		catch(Zerobalance e) {
			System.out.println(e);
			
		}
		

	}

}
