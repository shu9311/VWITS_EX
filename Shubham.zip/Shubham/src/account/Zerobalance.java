package account;

public class Zerobalance extends Exception {
	 
	private int bal;
	private int withdamt;
	private String accno;
	public Zerobalance(int bal, int withdamt, String accno) {
		super();
		this.bal = bal;
		this.withdamt = withdamt;
		this.accno = accno;
	}
	@Override
	public String toString() {
		return "Zerobalance [bal=" + bal + ", withdamt=" + withdamt + ", accno=" + accno + "]";
	}
	
	

}
